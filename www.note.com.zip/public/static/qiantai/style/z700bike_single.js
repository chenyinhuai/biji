eval(function (p, a, c, k, e, r) { e = function (c) { return (c < a ? '' : e(parseInt(c / a))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) : c.toString(36)) }; if (!''.replace(/^/, String)) { while (c--) r[e(c)] = k[c] || e(c); k = [function (e) { return r[e] } ]; e = function () { return '\\w+' }; c = 1 }; while (c--) if (k[c]) p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c]); return p } ('(4(a){a.18.1e=4(b){F b=a.1S({},a.18.1e.1o,b),9.Y(4(){4 w(g,h,i){Z(!p&&o){p=!0,b.1p(n+1);1T(g){1f"C":l=n,k=n+1,k=e===k?0:k,r=f*2,g=-f*2,n=k;1q;1f"G":l=n,k=n-1,k=k===-1?e-1:k,r=0,g=0,n=k;1q;1f"P":k=1U(i,10),l=a("."+b.D+" H."+b.Q+" a",c).L("M").1g("[^#/]+$"),k>l?(r=f*2,g=-f*2):(r=0,g=0),n=k}h==="1V"?b.1r?d.6(":7("+k+")",c).8({A:10}).R(b.I,b.J,4(){b.11?d.12({S:d.6(":7("+k+")",c).13()},b.19,4(){d.6(":7("+l+")",c).8({N:"14",A:0}),d.6(":7("+k+")",c).8({A:0}),b.T(k+1),p=!1}):(d.6(":7("+l+")",c).8({N:"14",A:0}),d.6(":7("+k+")",c).8({A:0}),b.T(k+1),p=!1)}):d.6(":7("+l+")",c).1s(b.I,b.J,4(){b.11?d.12({S:d.6(":7("+k+")",c).13()},b.19,4(){d.6(":7("+k+")",c).R(b.I,b.J)}):d.6(":7("+k+")",c).R(b.I,b.J,4(){a.1W.1X&&a(9).1Y(0).1Z.20("21")}),b.T(k+1),p=!1}):(d.6(":7("+k+")").8({B:r,N:"1t"}),b.11?d.12({B:g,S:d.6(":7("+k+")").13()},b.1h,b.1i,4(){d.8({B:-f}),d.6(":7("+k+")").8({B:f,A:5}),d.6(":7("+l+")").8({B:f,N:"14",A:0}),b.T(k+1),p=!1}):d.12({B:g},b.1h,b.1i,4(){d.8({B:-f}),d.6(":7("+k+")").8({B:f,A:5}),d.6(":7("+l+")").8({B:f,N:"14",A:0}),b.T(k+1),p=!1})),b.P&&(a("."+b.D+" H."+b.Q,c).22(b.Q),a("."+b.D+" H:7("+k+")",c).1u(b.Q))}}4 x(){1v(c.O("1a"))}4 y(){b.U?(1w(c.O("U")),1v(c.O("1a")),u=23(4(){1w(c.O("U")),v=1x(4(){w("C",i)},b.E),c.O("1a",v)},b.U),c.O("U",u)):x()}a("."+b.K,a(9)).6().24(\'<25 V="1j"/>\');15 c=a(9),d=a(".1j",c),e=d.6().26(),f=d.6().1y(),g=d.6().13(),h=b.1k-1,i=b.W.1z(",")<0?b.W:b.W.1A(" ","").1B(",")[0],j=b.W.1z(",")<0?i:b.W.1A(" ","").1B(",")[1],k=0,l=0,m=0,n=0,o,p,q,r,s,t,u,v;Z(e<2)F a("."+b.K,a(9)).R(b.I,b.J,4(){o=!0,b.1b()}),a("."+b.C+", ."+b.G).1s(0),!1;Z(e<2)F;h<0&&(h=0),h>e&&(h=e-1),b.1k&&(n=h),b.1c&&d.1c(),a("."+b.K,c).8({27:"28",1l:"1C"}),d.6().8({1l:"29",2a:0,B:d.6().1y(),A:0,N:"14"}),d.8({1l:"1C",2b:f*3,S:g,B:-f}),a("."+b.K,c).8({N:"1t"}),b.11&&(d.6().8({S:"2c"}),d.12({S:d.6(":7("+h+")").13()},b.19));Z(b.1D&&d.16("X:7("+h+")").1m){a("."+b.K,c).8({1E:"2d("+b.1F+") 2e-2f 1G% 1G%"});15 z=d.16("X:7("+h+")").L("1H")+"?"+(2g 2h).2i();a("X",c).2j().L("V")!="1j"?t=d.6(":7(0)")[0].2k.2l():t=d.16("X:7("+h+")"),d.16("X:7("+h+")").L("1H",z).2m(4(){d.16(t+":7("+h+")").R(b.I,b.J,4(){a(9).8({A:5}),a("."+b.K,c).8({1E:""}),o=!0,b.1b()})})}2n d.6(":7("+h+")").R(b.I,b.J,4(){o=!0,b.1b()});b.1I&&(d.6().8({2o:"2p"}),d.6().17(4(){F w("C",i),!1})),b.1J&&b.E&&(d.1K("2q",4(){x()}),d.1K("2r",4(){y()})),b.1L&&(a("."+b.K,c).1M(\'<a M="#" V="\'+b.G+\'">2s</a>\'),a("."+b.G,c).1M(\'<a M="#" V="\'+b.C+\'">2t</a>\')),a("."+b.C,c).17(4(a){a.1N(),b.E&&y(),w("C",i)}),a("."+b.G,c).17(4(a){a.1N(),b.E&&y(),w("G",i)}),b.1O?(b.1P?c.2u("<1d V="+b.D+"></1d>"):c.1Q("<1d V="+b.D+"></1d>"),d.6().Y(4(){a("."+b.D,c).1Q(\'<H><a M="#\'+m+\'">\'+(m+1)+"</a></H>"),m++})):a("."+b.D+" H a",c).Y(4(){a(9).L("M","#"+m),m++}),a("."+b.D+" H:7("+h+")",c).1u(b.Q),a("."+b.D+" H a",c).17(4(){F b.E&&y(),q=a(9).L("M").1g("[^#/]+$"),n!=q&&w("P",j,q),!1}),a("a.2v",c).17(4(){F b.E&&y(),q=a(9).L("M").1g("[^#/]+$")-1,n!=q&&w("P",j,q),!1}),b.E&&(v=1x(4(){w("C",i)},b.E),c.O("1a",v))})},a.18.1e.1o={1D:!1,1F:"/X/2w.2x",K:"2y",1L:!1,C:"C",G:"G",P:!0,1O:!0,1P:!1,D:"P",Q:"2z",I:1n,J:"",1h:1n,1i:"",1k:1,W:"2A",1r:!1,1c:!1,E:0,U:0,1J:!1,11:!1,19:1n,1I:!1,1p:4(){},T:4(){},1b:4(){}},a.18.1c=4(b){4 c(){F 1R.2B(1R.2C())-.5}F a(9).Y(4(){15 d=a(9),e=d.6(),f=e.1m;Z(f>1){e.2D();15 g=[];2E(i=0;i<f;i++)g[g.1m]=i;g=g.2F(c),a.Y(g,4(a,c){15 f=e.7(c),g=f.2G(!0);g.2H().2I(d),b!==2J&&b(f,g),f.2K()})}})}})(2L);', 62, 172, '||||function||children|eq|css|this|||||||||||||||||||||||||||zIndex|left|next|paginationClass|play|return|prev|li|fadeSpeed|fadeEasing|container|attr|href|display|data|pagination|currentClass|fadeIn|height|animationComplete|pause|class|effect|img|each|if||autoHeight|animate|outerHeight|none|var|find|click|fn|autoHeightSpeed|interval|slidesLoaded|randomize|ul|slides|case|match|slideSpeed|slideEasing|slides_control|start|position|length|350|option|animationStart|break|crossfade|fadeOut|block|addClass|clearInterval|clearTimeout|setInterval|outerWidth|indexOf|replace|split|relative|preload|background|preloadImage|50|src|bigTarget|hoverPause|bind|generateNextPrev|after|preventDefault|generatePagination|prependPagination|append|Math|extend|switch|parseInt|fade|browser|msie|get|style|removeAttribute|filter|removeClass|setTimeout|wrapAll|div|size|overflow|hidden|absolute|top|width|auto|url|no|repeat|new|Date|getTime|parent|tagName|toLowerCase|load|else|cursor|pointer|mouseover|mouseleave|Prev|Next|prepend|link|loading|gif|slides_container|current|slide|round|random|hide|for|sort|clone|show|appendTo|undefined|remove|jQuery'.split('|'), 0, {}));

jQuery(function ($) {

    $(window).load(function () {
        $('#slides_container .slide').each(function () {
            var $thisImg = $(this).find('img'), pic_src = $thisImg.attr('src'), $caption = $(this).find('.caption');
            var ni = new Image();
            ni.onload = function () {
                var w = ni.width, h = ni.height, x = 1024, y = 735;
                if (w > x) {
                    h = h * (x / w);
                    w = x;
                    if (h > y) {
                        w = w * (y / h);
                        h = y;
                    }
                } else if (h > y) {
                    w = w * (y / h);
                    h = y;
                    if (w > x) {
                        h = h * (x / w);
                        w = x;
                    }
                }
                var margin_l = (w < x) ? (x - w) / 2 : 0, margin_t = (h < y) ? (y - h) / 2 : 0;
                // alert(w+'/'+h+'/'+margin_l+'/'+margin_t);
                // $thisImg.css({"width":w+"px","height":h+"px"});
                $thisImg.css({ "width": w + "px", "height": h + "px", "margin-left": margin_l + "px", "margin-top": margin_t + "px" });
                $caption.css({ "width": w + "px", "left": margin_l + "px", "bottom": margin_t + "px" });
            }
            ni.src = pic_src;
        });

        //$("#slides_number").html(ii);
        $('#products').slides({
            preload: true,
            preloadImage: themeurl() + '/img/loading.gif',
            effect: 'slide,fade',
            crossfade: true,
            slideSpeed: 350,
            fadeSpeed: 500,
            generateNextPrev: true,
            generatePagination: false
        });

    });
    var myinterval = setInterval(function () {
        if ($(".next").html() != null) {
            $(".next").click(function () {
                var n = $("#slides_number");
                var a = parseInt($("#slides_all").html());
                var c = parseInt(n.html()) + 1;
                if (a < c) {
                    c = "01";
                }
                else if (c < 10) {
                    c = "0" + c;
                }
                n.html(c);
            });
            $(".prev").click(function () {
                var n = $("#slides_number");
                var a = parseInt($("#slides_all").html());
                var c = parseInt(n.html()) - 1;
                if (c == 0) {
                    c = a;
                }
                if (c < 10) {
                    c = "0" + c;
                }
                n.html(c);
            });
            clearInterval(myinterval);
        }
    }, 1000);
});
function GoImg(i) {
    if (parseInt(i) < 10) {
        i = "0" + i;
    }
    document.getElementById("slides_number").innerHTML = i;
}
function themeurl() {
    var i = 0, got = -1, url, len = document.getElementsByTagName('link').length;
    while (i <= len && got == -1) {
        url = document.getElementsByTagName('link')[i].href;
        got = url.indexOf('/style.css');
        i++;
    }
    return url.replace('/style.css', '');
};