<?php

declare(strict_types=1);

namespace app\houtai\controller;

use think\facade\View;
use think\facade\Db;
use think\facade\Request;

/**加载数据库**/

use app\BaseController;
use think\facade\Session;
use think\captcha\facade\Captcha;
use app\index\validate\Authusers;


class User extends Base
//index控制器对应目录，Index类对应view下面的目录

{
    public function index() //index方法对应HTML代码，index方法对应view下面的目录里的静态文件

    {
        $tittle = '笔记管理系统';
        $login = '陈银懷';
        // $left = Db::table('menu')->where('fid', 0)->select();
        // $left->toArray();
        // foreach ($left as &$v) {
        //     $son = Db::table('menu')->where('fid', $v['id'])->select();
        //     $v['lists'] = $son->toArray();
        // }
        // // print_r($left);
        // $right = Db::table('art')->select();

        $menu = Db::table('menu')->where('fid', 0)->select();
        $left = $menu->toArray();
        foreach ($left as &$left_v) {
            $left_v['lists'] = Db::table('menu')->where('fid', $left_v['id'])->select();
        }

        $param = Request::param();
        if (isset($param['status']) && $param['status']) {
            $where['status'] = $param['status'];
            // } else if (isset($param['status']) && $param['status'] == 2) {
            //     $where['status'] = 2;
        } else {
            $where = true;
        }

        $p = isset($param['p']) ? (int)$param['p'] : 1;
        // 统计总数
        $count = Db::table('user')->where($where)->count();



        $list = Db::table('user')->where($where)->order('user_id DESC')->page($p, 3)->select();

        $right = $list->toArray();
        // foreach ($right as &$right_v) {
        //     $right_v['cat_id'] = Db::table('cat')->where('cat_id', $right_v['cat_id'])->value('catname');
        // }
        View::assign([
            'tittle'  => $tittle,
            'login' => $login,
            'left' => $left,
            'right' => $right,
            'list' => $list,
            'count' => ceil($count / 3),
            'p' => $p,

            'status' => isset($param['status']) ? $param['status'] : 0
        ]);
        return View::fetch("index");
    }
    public function edit()
    {
        $id = Request::param('user_id');
        // print_r($id);
        $shop = Db::table('user')->where('user_id', $id)->find();
        $cat = Db::table('cat')->where('status', 1)->select();
        View::assign([
            'shop' => $shop,
            'cat' => $cat
        ]);
        return View::fetch();
    }
    public function edits()
    {
        // print_r( Request::param() );
        // print_r( Request::post() );

        $all = Request::param();
        // print_r($all);
        $update = Db::table('user')->where('user_id', $all['user_id'])->update($all);
        if ($update) {
            echo json_encode(['code' => 0, 'msg' => '修改成功']);
        } else {
            echo json_encode(['code' => 1, 'msg' => '修改失败']);
        }
    }
    public function add()
    {
        if (Request::method() == 'POST') {
            $all = Request::param();
            $insert = Db::table('user')->insert($all);
            if ($insert) {
                echo json_encode(['code' => 0, 'msg' => '添加成功']);
            } else {
                echo json_encode(['code' => 1, 'msg' => '添加失败']);
            }
        } else {
            $cat = Db::table('cat')->where('status', 1)->select();
            View::assign([
                'cat' => $cat
            ]);
            return View::fetch("add");
        }
    }
    public function del()
    {
        $id = Request::param('user_id');
        $delete = Db::table('user')->where('user_id', $id)->delete();
        if ($delete) {
            echo json_encode(['code' => 0, 'msg' => '删除成功']);
        } else {
            echo json_encode(['code' => 1, 'msg' => '删除失败']);
        }
    }
}