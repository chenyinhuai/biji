<?php

namespace app\houtai\controller;

use think\facade\Db;

class Login extends  Base
{
    //登录逻辑：
    //  访问后台首页：已经合法登录-》在首页
    //  没有登录=》登录
    // 登录：已经合法登录-》在后台首页
    // 没有登录=》登录
    public function initialize()
    //login和base都有初始化，父类就不执行了，被覆盖了，这里是子类。
    {
        //已登录直接跳转
        $account = session('adminAccount');
        if ($account && $account['user_id']) {
            return $this->redirect(url('index/index'));
        }
    }
    //后台登录的逻辑
    public function index()
    {
        if (request()->isPost()) {
            //判断是不是post请求
            $data = input('post.');
            // 通过用户名 获取 用户相关信息
            //halt($data);
            $adminData = Db::table('user')->where('username', $data['username'])->find(); //一维数组
            //halt($adminData);
            if (!$adminData || $adminData['status'] != 1) {
                return alert('用户不存在，或者此用户未被审核通过', 'index', 5, 3);
                //失败后跳转index，哭，时间3
            }
            // if (!captcha_check($data['verifycode'])) {
            //     // 校验失败
            //     return alert('验证码不正确', 'index', 5, 3);
            // }

            //if ($adminData['password'] != password_salt($data['password']))
            //放弃密码加盐，思来想去还是不能太复杂，怎么弄也都没有成功，也不明白哪里错了，我好菜啊，苦恼
            if ($adminData['password'] != $data['password']) {
                return alert('密码不正确', 'index', 5, 3);
            }
            session('adminAccount', $adminData);
            //助手函数
            return alert('登录成功！', 'index/index', 6, 3);
        } else {
            return view();
            //没有就模板渲染
        }
    }
}