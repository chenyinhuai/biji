<?php

declare(strict_types=1);

namespace app\houtai\controller;

use think\facade\View;
use think\facade\Db;

/**加载数据库**/

use app\BaseController;
use think\facade\Session;
use think\captcha\facade\Captcha;
use app\index\validate\Authusers;

class Test //index控制器对应目录，Index类对应view下面的目录

{
    // public function index() //index方法对应HTML代码，index方法对应view下面的目录里的静态文件

    // {
    //     $arr = [
    //         [
    //             'id' => 1,
    //             'name' => '欧阳克'
    //         ],
    //         [
    //             'id' => 2,
    //             'name' => '朱老师'
    //         ],
    //         [
    //             'id' => 3,
    //             'name' => '西门大官人'
    //         ]
    //     ];
    //     View::assign('arr', $arr);
    //     return View::fetch();
    // }

    // public function index()
    // {
    //     $status = 1;
    //     $order_status = 4;
    //     View::assign('status', $status);
    //     View::assign('order_status', $order_status);
    //     return View::fetch();
    // }

    // public function index()
    // {
    //     $query = Db::query("SELECT * FROM `menu` where status=1");
    //     print_r($query);
    // }

    // public function index(){
    //     $execute = Db::execute("INSERT INTO `shop_goods` VALUES (3, 1, '2019秋冬新款时尚简约纯羊绒加厚圆领羊绒长裙显瘦气质连衣裙女', 1179.00, 0, 200, 1, 1576080000)");
    //     print_r($execute);
    //     $execute = Db::execute("UPDATE `shop_goods` set `price`='1100' where `id`=3 ");
    //     print_r($execute);
    // }


    // public function index()
    // {

    //     $find = Db::table('art')->find();
    //     print_r($find);
    // }

    // public function index()
    // {
    //     $select = Db::table('art')->select();
    //     print_r($select);
    // }

    // public function index()
    // {
    //     $select = Db::table('art')->value('tittle');
    //     print_r($select);
    // }

    // public function index()
    // {
    //     $select = Db::table('art')->column('tittle');
    //     print_r($select);
    // }

    // public function index(){
    //     # 添加数据
    //     $data = ['cat'=>'2','title'=>'美特斯邦威七分牛仔裤女2018夏季新款中腰修身洗水牛仔裤商场款','price'=>'49.90','add_time'=>1576080000];
    //     $save = Db::table('shop_goods')->save($data);
    //     print_r($save);
    //     # 修改数据
    //     $data = ['price'=>'99.00','id'=>3];
    //     $save = Db::table('shop_goods')->save($data);
    //     print_r($save);
    // }

    public function index()
    {
        $select = Db::table('art')->where('art_id', 15)->select();
        if ($select->isEmpty()) {
            echo '未找到数据';
            exit;
        }
        print_r($select->toArray());
    }
}