<?php

declare(strict_types=1);

namespace app\qiantai\controller;

use think\facade\View;
use think\facade\Db;
use think\facade\Request;

/**加载数据库**/

use app\BaseController;
use think\facade\Session;
use think\captcha\facade\Captcha;
use app\index\validate\Authusers;


// class Index //index控制器对应目录，Index类对应view下面的目录

// {
//     public function index() //index方法对应HTML代码，index方法对应view下面的目录里的静态文件

//     {
//         return View::fetch();
//     }
// }

class Index extends Base //index控制器对应目录，Index类对应view下面的目录

{
    public function index() //index方法对应HTML代码，index方法对应view下面的目录里的静态文件

    {
        $tittle = '笔记管理系统';
        $login = '陈银懷';
        // $left = Db::table('menu')->where('fid', 0)->select();
        // $left->toArray();
        // foreach ($left as &$v) {
        //     $son = Db::table('menu')->where('fid', $v['id'])->select();
        //     $v['lists'] = $son->toArray();
        // }
        // // print_r($left);
        // $right = Db::table('art')->select();

        $menu = Db::table('menu')->where('fid', 0)->select();
        $left = $menu->toArray();
        foreach ($left as &$left_v) {
            $left_v['lists'] = Db::table('menu')->where('fid', $left_v['id'])->select();
        }

        $list = Db::table('art')->select();
        $right = $list->toArray();
        // foreach ($right as &$right_v) {
        //     $right_v['cat'] = Db::table('cat')->where('cat_id', $right_v['cat'])->value('catname');
        // }

        View::assign([
            'tittle' => $tittle,
            'login' => $login,
            'left' => $left,
            'right' => $right
        ]);
        return View::fetch("index");
    }
    public function article() //index方法对应HTML代码，index方法对应view下面的目录里的静态文件

    {
        $tittle = '笔记管理系统';
        $login = '陈银懷';

        $menu = Db::table('menu')->where('fid', 0)->select();
        $left = $menu->toArray();
        foreach ($left as &$left_v) {
            $left_v['lists'] = Db::table('menu')->where('fid', $left_v['id'])->select();
        }

        $list = Db::table('art')->select();
        $right = $list->toArray();
        // foreach ($right as &$right_v) {
        //     $right_v['cat'] = Db::table('cat')->where('cat_id', $right_v['cat'])->value('catname');
        // }

        View::assign([
            'tittle' => $tittle,
            'login' => $login,
            'left' => $left,
            'right' => $right
        ]);

        return view::fetch();
    }
    public function page()

    {
        return view::fetch();
    }
    public function edit()
    {
        $id = Request::param('art_id');
        // print_r($id);
        $shop = Db::table('art')->where('art_id', $id)->find();
        $cat = Db::table('cat')->where('status', 1)->select();
        View::assign([
            'shop' => $shop,
            'cat' => $cat
        ]);
        return View::fetch();
    }
    public function edits()
    {
        // print_r( Request::param() );
        // print_r( Request::post() );

        $all = Request::param();
        // print_r($all);
        $update = Db::table('art')->where('art_id', $all['art_id'])->update($all);
        if ($update) {
            echo json_encode(['code' => 0, 'msg' => '修改成功']);
        } else {
            echo json_encode(['code' => 1, 'msg' => '修改失败']);
        }
    }
}