<?php /*a:4:{s:68:"D:\phpstudy_pro\WWW\www.note.com\app\qiantai\view\artlist\index.html";i:1675054652;s:68:"D:\phpstudy_pro\WWW\www.note.com\app\qiantai\view\public\header.html";i:1674998805;s:73:"D:\phpstudy_pro\WWW\www.note.com\app\qiantai\view\public\header_wrap.html";i:1675062434;s:68:"D:\phpstudy_pro\WWW\www.note.com\app\qiantai\view\public\footer.html";i:1675054364;}*/ ?>
﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- <html xmlns="http://www.w3.org/1999/xhtml"> -->
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8" />
  <title>笔记管理系统</title>
  <meta name="description" content="笔记管理系统" />
  <meta name="keywords" content="笔记管理系统" />
  <link
    rel="stylesheet"
    type="text/css"
    media="all"
    href="/static/qiantai/style/style.css"
  />
  <script
    type="text/javascript"
    src="/static/qiantai/style/jquery-1.4.1.min.js"
  ></script>
  <script type="text/javascript" src="/static/qiantai/style/jquery.js"></script>
  <script
    src="/static/qiantai/style/jquery.error.js"
    type="text/javascript"
  ></script>
  <script
    src="/static/qiantai/style/jtemplates.js"
    type="text/javascript"
  ></script>
  <script
    src="/static/qiantai/style/jquery.form.js"
    type="text/javascript"
  ></script>
  <script src="/static/qiantai/style/lazy.js" type="text/javascript"></script>
  <script
    type="text/javascript"
    src="/static/qiantai/style/wp-sns-share.js"
  ></script>
  <script
    type="text/javascript"
    src="/static/qiantai/style/voterajax.js"
  ></script>
  <script
    type="text/javascript"
    src="/static/qiantai/style/userregister.js"
  ></script>
  <link
    rel="stylesheet"
    href="/static/qiantai/style/pagenavi-css.css"
    type="text/css"
    media="all"
  />
  <link
    rel="stylesheet"
    href="/static/qiantai/style/votestyles.css"
    type="text/css"
  />
  <link
    rel="stylesheet"
    href="/static/qiantai/style/voteitup.css"
    type="text/css"
  />

  <link
    rel="stylesheet"
    href="/static/qiantai/style/list.css"
    type="text/css"
  />
  <link
    rel="stylesheet"
    href="/static/qiantai/style/fenye.css"
    type="text/css"
  />
  <link rel="stylesheet" href="./style/article.css" type="text/css" />

  <style type="text/css">
    #wrapper {
      background-color: #ffffff;
    }
    .single_entry {
      margin-top: 30px;
    }
  </style>
  <script type="text/javascript">
    function IFocuse(th, o) {
      var t = $(th);
      var c = t.attr("class");
      if (o) {
        t.removeClass(c).addClass(c + "-over");
      } else {
        t.removeClass(c).addClass(c.replace("-over", ""));
      }
    }
  </script>
  <script
    language="javascript"
    type="text/javascript"
    src="/include/dedeajax2.js"
  ></script>
  <script language="javascript" type="text/javascript"></script>
</script>
<script type="text/javascript">

function ILike(th, v) {
    if (v) {
        $(th).addClass("single_views_over");
    }
    else {
        $(th).removeClass("single_views_over");
    }
}

</script>
</head>

<body id="list_style_2" class="list_style_2">
  <script>
    function subForm() {
      formsearch.submit();
      //form1为form的id
    }
  </script>
  <script type="text/javascript">
    function showMask() {
      $("#mask").css("height", $(document).height());
      $("#mask").css("width", $(document).width());
      $("#mask").show();
    }
  </script>
  <div id="mask" class="mask" onclick="CloseMask()"></div>
  <div id="header_wrap">
    <div id="header">
        <div style="float: left; width: 310px;">
            <h1>
                <a href="http://www.note.com/index.php/qiantai/index/index" title="宽屏大气文章类--41天鹰模板">宽屏大气文章类--41天鹰模板</a>
                <div class="" id="logo-sub-class">
                </div>
            </h1>
        </div>
        <div id="navi">

                <ul id="jsddm">
                    <li><a class="navi_home" href="http://www.note.com/index.php/qiantai/index/index">首页</a></li>
                    <li><a class="navi_home" target="_blank" href="https://www.php.cn/course/1086.html">视频教程</a></li>
                    <li><a href="http://www.note.com/index.php/qiantai/artlist/index">笔记分类</a>
                    <ul>
                        <li><a href="http://www.note.com/index.php/qiantai/artlist/index">文学历史</a></li>
                        <li><a href="http://www.note.com/index.php/qiantai/artlist/index">法律哲思</a></li>
                        <li><a href="http://www.note.com/index.php/qiantai/artlist/index">科学技术</a></li>
                    </ul>
                    <!-- </li2><li><a href="/gear/">骑行装备</a>
                    <ul>
                        <li><a href="/gear/accessories/">车身装备</a></li>
                        <li><a href="/gear/rs/">人身装备</a></li>
                    </ul>
                     -->
                    <!-- </li2><li><a href="/news/">行业资讯</a> -->
                    </li2><li><a href="http://www.note.com/index.php/qiantai/index/page">关于我们</a>
                    </li2>
                </ul>

            <div style="clear: both;">
            </div>

            
        </div>
        <div style="float: right; width: 209px;">
            <!-- <div class="widget" style="height: 30px; padding-top: 20px;">
                <div style="float: left;">
              <form  name="formsearch" action="/plus/search.php"><input type="hidden" name="kwtype" value="0" />                
                <input name="q" type="text" style="background-color: #000000;padding-left: 10px; font-size: 12px;font-family: 'Microsoft Yahei'; color: #999999;height: 29px; width: 160px; border: solid 1px #666666; line-height: 28px;" id="go" value="在这里搜索..." onfocus="if(this.value=='在这里搜索...'){this.value='';}"  onblur="if(this.value==''){this.value='在这里搜索...';}" />
             </form>
                 </div>
                <div style="float: left;">
                    <img src="/static/qiantai/images/search-new.png" id="imgSearch" style="cursor: pointer; margin: 0px;
                        padding: 0px;" onclick="subForm()"  /></div>
                <div style="clear: both;">
                </div>
            </div> -->
        </div>
        
    </div>
</div>

</div>
  <div id="wrapper">
    <div id="xh_container">
      <div id="xh_content">
        <div class="path">
          <a href="#">主页</a> >
          <a href="http://www.note.com/index.php/qiantai/artlist/index"
            >笔记分类</a
          >
          >
        </div>
        <div class="clear"></div>
        <div class="xh_area_h_3" style="margin-top: 40px">
          <?php if(is_array($right) || $right instanceof \think\Collection || $right instanceof \think\Paginator): $i = 0; $__LIST__ = $right;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$right_v): $mod = ($i % 2 );++$i;?>

          <div class="xh_post_h_3 ofh">
            <div class="xh_265x265">
              <a
                target="_blank"
                href="/life/392.html"
                title="<?php echo htmlentities($right_v['tittle']); ?>"
              >
                <img
                  src="/static/qiantai/images/dushu.jpg"
                  alt="<?php echo htmlentities($right_v['tittle']); ?>"
                  height="240"
                  width="400"
              /></a>
            </div>
            <div class="r ofh">
              <h2 class="xh_post_h_3_title ofh">
                <a
                  target="_blank"
                  href="http://www.note.com/index.php/qiantai/index/article"
                  title="<?php echo htmlentities($right_v['tittle']); ?>"
                  ><?php echo htmlentities($right_v['tittle']); ?></a
                >
              </h2>
              <span class="time"><?php echo htmlentities(date('Y-m-d',!is_numeric($right_v['lastup'])? strtotime($right_v['lastup']) : $right_v['lastup'])); ?></span>
              <div class="xh_post_h_3_entry ofh"><?php echo htmlentities($right_v['content']); ?></div>
              <!-- <div class="b">
                                     <span title="2人赞" class="xh_love"><span class="textcontainer"><span>2</span></span> <span class="bartext"></span></span> <span title="119人浏览" class="xh_views">119</span>
                                </div> -->
            </div>
            <span class="cat"
              ><a
                href="/life/"
                title="查看 单车生活 中的全部文章"
                rel="category tag"
                >笔记</a
              ></span
            >
          </div>
          <?php endforeach; endif; else: echo "" ;endif; ?>
          <!-- 
          <div id="pagination">
            <div class="wp-pagenavi">
              <span class="current">1</span
              ><a class="page larger" href="list_2.html">2</a
              ><a class="page larger" href="list_3.html">3</a
              ><a class="page larger" href="list_4.html">4</a
              ><a class="page larger" href="list_5.html">5</a
              ><a class="page larger" href="list_6.html">6</a
              ><a class="page larger" href="list_7.html">7</a
              ><a class="page larger" href="list_8.html">8</a
              ><a class="page larger" href="list_9.html">9</a
              ><a class="page larger" href="list_10.html">10</a
              ><a class="page larger" href="list_11.html">11</a
              ><a class="page larger" href="list_2.html">下一页</a
              ><a class="page larger" href="list_28.html">末页</a
              ><span class="pages">共 28 页，280条</span>
            </div>
          </div> -->
        </div>
      </div>
      <div id="xh_sidebar">
        <!-- 右侧 -->
        <div class="widget">
          <div
            style="
              background: url('./style/img/hots_bg.png') no-repeat scroll 0 0
                transparent;
              width: 250px;
              height: 52px;
              margin-bottom: 15px;
            "
          ></div>
          <ul id="ulHot">
            <?php if(is_array($right) || $right instanceof \think\Collection || $right instanceof \think\Paginator): $i = 0; $__LIST__ = $right;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$right_v): $mod = ($i % 2 );++$i;?>
            <li
              style="
                border-bottom: dashed 1px #ccc;
                height: 70px;
                margin-bottom: 15px;
              "
            >
              <div
                style="float: left; width: 85px; height: 55px; overflow: hidden"
              >
                <a
                  href="http://www.note.com/index.php/qiantai/index/article"
                  target="_blank"
                  ><img
                    src="/static/qiantai/images/dushu.jpg"
                    width="83"
                    title="<?php echo htmlentities($right_v['tittle']); ?>"
                /></a>
              </div>
              <div
                style="
                  float: right;
                  width: 145px;
                  height: 52px;
                  overflow: hidden;
                "
              >
                <a
                  href="http://www.note.com/index.php/qiantai/index/article"
                  target="_blank"
                  title="<?php echo htmlentities($right_v['tittle']); ?>"
                  ><?php echo htmlentities($right_v['tittle']); ?></a
                >
              </div>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
          </ul>
        </div>

        <!-- <div class="widget portrait">
                <div>
                    <div class="textwidget">
                        <a href="/tougao.html"><img src="./style/img/tg.jpg" alt="鎶曠ǹ"></a><br><br>          
                        <script type="text/javascript">BAIDU_CLB_fillSlot("870073");</script>
                        <script type="text/javascript">BAIDU_CLB_fillSlot("870080");</script>
                        <script type="text/javascript">BAIDU_CLB_fillSlot("870081");</script>
                    </div>
                </div>
            </div> -->
      </div>
      <div class="clear"></div>
    </div>
    <div class="boxBor"></div>

    <div class="boxBor" onclick="IBoxBor()" style="cursor: pointer"></div>
    <script type="text/javascript">
      $(function () {
        var imgHoverSetTimeOut = null;
        $(".xh_265x265 img").hover(
          function () {
            var oPosition = $(this).offset();
            var oThis = $(this);
            $(".boxBor").css({
              left: oPosition.left,
              top: oPosition.top,
              width: oThis.width(),
              height: oThis.height(),
            });
            $(".boxBor").show();
            var urlText = $(this).parent().attr("href");
            $("#hdBoxbor").val(urlText);
          },
          function () {
            imgHoverSetTimeOut = setTimeout(function () {
              $(".boxBor").hide();
            }, 500);
          }
        );
        $(".boxBor").hover(
          function () {
            clearTimeout(imgHoverSetTimeOut);
          },
          function () {
            $(".boxBor").hide();
          }
        );
      });
      function IBoxBor() {
        window.open($("#hdBoxbor").val());
      }
      function goanewurl() {
        window.open($("#hdUrlFocus").val());
      }
    </script>
  </div>

  <div class="sitemap">
    <h4>
        SITE MAP</h4>
    <div class="l">
        <ul id="menu-sitemap" class="menu">
            <li class="menu-item menu-item-type-custom menu-item-object-custom">
                <a target="_blank" href="http://www.note.com/index.php/qiantai/index/index">首页</a>
                <ul class="sub-menu"> 
                </ul>
            </li>  
                <li class="menu-item menu-item-type-custom menu-item-object-custom">
                <a target="_blank" href="http://www.note.com/index.php/qiantai/index/article">笔记分类</a>
                <ul class="sub-menu">    
                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category">
                        <a target="_blank" href="http://www.note.com/index.php/qiantai/index/article">文学历史</a></li>         
                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category">
                        <a target="_blank" href="http://www.note.com/index.php/qiantai/index/article">法律哲思</a></li>            
                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category">
                        <a target="_blank" href="http://www.note.com/index.php/qiantai/index/article">科学技术</a></li>
                </ul>
            </li>          
             <li class="menu-item menu-item-type-custom menu-item-object-custom">
                <a target="_blank" href="http://www.note.com/index.php/qiantai/index/article">关于</a>
                <ul class="sub-menu">
                          <li class="menu-item menu-item-type-custom menu-item-object-custom">
                        <a target="_blank" href="http://www.note.com/index.php/qiantai/index/page">关于我们</a></li>                      
                </ul>
            </li>
      </ul>
    </div>
    <div class="r">
        <h5>FOLLOW US</h5>
        <img src="/static/qiantai/images/weixin1.jpg" alt="" title="扫描添加我们的公众微信" height="140" width="120"></a></div>
</div>

<script>document.getElementById("life"+"").style.display="n"+"o"+"ne";</script>
</body>
</html>

</body>
