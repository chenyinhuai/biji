<?php /*a:4:{s:68:"D:\phpstudy_pro\WWW\www.note.com\app\qiantai\view\index\article.html";i:1675053383;s:68:"D:\phpstudy_pro\WWW\www.note.com\app\qiantai\view\public\header.html";i:1674998805;s:73:"D:\phpstudy_pro\WWW\www.note.com\app\qiantai\view\public\header_wrap.html";i:1675055069;s:68:"D:\phpstudy_pro\WWW\www.note.com\app\qiantai\view\public\footer.html";i:1675054364;}*/ ?>
﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- <html xmlns="http://www.w3.org/1999/xhtml"> -->
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8" />
  <title>笔记管理系统</title>
  <meta name="description" content="笔记管理系统" />
  <meta name="keywords" content="笔记管理系统" />
  <link
    rel="stylesheet"
    type="text/css"
    media="all"
    href="/static/qiantai/style/style.css"
  />
  <script
    type="text/javascript"
    src="/static/qiantai/style/jquery-1.4.1.min.js"
  ></script>
  <script type="text/javascript" src="/static/qiantai/style/jquery.js"></script>
  <script
    src="/static/qiantai/style/jquery.error.js"
    type="text/javascript"
  ></script>
  <script
    src="/static/qiantai/style/jtemplates.js"
    type="text/javascript"
  ></script>
  <script
    src="/static/qiantai/style/jquery.form.js"
    type="text/javascript"
  ></script>
  <script src="/static/qiantai/style/lazy.js" type="text/javascript"></script>
  <script
    type="text/javascript"
    src="/static/qiantai/style/wp-sns-share.js"
  ></script>
  <script
    type="text/javascript"
    src="/static/qiantai/style/voterajax.js"
  ></script>
  <script
    type="text/javascript"
    src="/static/qiantai/style/userregister.js"
  ></script>
  <link
    rel="stylesheet"
    href="/static/qiantai/style/pagenavi-css.css"
    type="text/css"
    media="all"
  />
  <link
    rel="stylesheet"
    href="/static/qiantai/style/votestyles.css"
    type="text/css"
  />
  <link
    rel="stylesheet"
    href="/static/qiantai/style/voteitup.css"
    type="text/css"
  />

  <link
    rel="stylesheet"
    href="/static/qiantai/style/list.css"
    type="text/css"
  />
  <link
    rel="stylesheet"
    href="/static/qiantai/style/fenye.css"
    type="text/css"
  />
  <link rel="stylesheet" href="./style/article.css" type="text/css" />

  <style type="text/css">
    #wrapper {
      background-color: #ffffff;
    }
    .single_entry {
      margin-top: 30px;
    }
  </style>
  <script type="text/javascript">
    function IFocuse(th, o) {
      var t = $(th);
      var c = t.attr("class");
      if (o) {
        t.removeClass(c).addClass(c + "-over");
      } else {
        t.removeClass(c).addClass(c.replace("-over", ""));
      }
    }
  </script>
  <script
    language="javascript"
    type="text/javascript"
    src="/include/dedeajax2.js"
  ></script>
  <script language="javascript" type="text/javascript"></script>
</script>
<script type="text/javascript">

function ILike(th, v) {
    if (v) {
        $(th).addClass("single_views_over");
    }
    else {
        $(th).removeClass("single_views_over");
    }
}

</script>
</head>


<!--

function postBadGood(ftype,fid)
{
    var taget_obj = document.getElementById(ftype+fid);
    var saveid = GetCookie('badgoodid');
    if(saveid != null)
    {
        var saveids = saveid.split(',');
        var hasid = false;
        saveid = '';
        j = 1;
        for(i=saveids.length-1;i>=0;i--)
        {
            if(saveids[i]==fid && hasid) continue;
            else {
                if(saveids[i]==fid && !hasid) hasid = true;
                saveid += (saveid=='' ? saveids[i] : ','+saveids[i]);
                j++;
                if(j==10 && hasid) break;
                if(j==9 && !hasid) break;
            }
        }
        if(hasid) { alert('您刚才已表决过了喔！'); return false;}
        else saveid += ','+fid;
        SetCookie('badgoodid',saveid,1);
    }
    else
    {
        SetCookie('badgoodid',fid,1);
    }
    myajax = new DedeAjax(taget_obj,false,false,'','','');
    myajax.SendGet2("/plus/feedback.php?aid="+fid+"&action="+ftype+"&fid="+fid);
}
function postDigg(ftype,aid)
{
    var taget_obj = document.getElementById('newdigg');
    var saveid = GetCookie('diggid');
    if(saveid != null)
    {
        var saveids = saveid.split(',');
        var hasid = false;
        saveid = '';
        j = 1;
        for(i=saveids.length-1;i>=0;i--)
        {
            if(saveids[i]==aid && hasid) continue;
            else {
                if(saveids[i]==aid && !hasid) hasid = true;
                saveid += (saveid=='' ? saveids[i] : ','+saveids[i]);
                j++;
                if(j==20 && hasid) break;
                if(j==19 && !hasid) break;
            }
        }
        if(hasid) { alert("您已经顶过该帖，请不要重复顶帖 ！"); return; }
        else saveid += ','+aid;
        SetCookie('diggid',saveid,1);
    }
    else
    {
        SetCookie('diggid',aid,1);
    }
    myajax = new DedeAjax(taget_obj,false,false,'','','');
    var url = "/plus/digg_ajax.php?action="+ftype+"&id="+aid;
    myajax.SendGet2(url);
}
function getDigg(aid)
{
    var taget_obj = document.getElementById('newdigg');
    myajax = new DedeAjax(taget_obj,false,false,'','','');
    myajax.SendGet2("/plus/digg_ajax.php?id="+aid);
    DedeXHTTP = null;
}
-->

 

<body class="single2">
   <script>
 function subForm()
 {

 formsearch.submit();
 //form1为form的id
 }
 </script>
<script type="text/javascript">
    function showMask() {
        $("#mask").css("height", $(document).height());
        $("#mask").css("width", $(document).width());
        $("#mask").show();
    }  
</script>
<div id="mask" class="mask" onclick="CloseMask()"></div> 
<div id="header_wrap">
    <div id="header">
        <div style="float: left; width: 310px;">
            <h1>
                <a href="http://www.note.com/index.php/qiantai/index/index" title="宽屏大气文章类--41天鹰模板">宽屏大气文章类--41天鹰模板</a>
                <div class="" id="logo-sub-class">
                </div>
            </h1>
        </div>
        <div id="navi">

                <ul id="jsddm">
                    <li><a class="navi_home" href="http://www.note.com/index.php/qiantai/index/index">首页</a></li>
                    <li><a class="navi_home" target="_blank" href="https://www.php.cn/course/1086.html">视频教程</a></li>
                    <li><a href="http://www.note.com/index.php/qiantai/artlist/index">笔记分类</a>
                    <ul>
                        <li><a href="http://www.note.com/index.php/qiantai/index/article">文学历史</a></li>
                        <li><a href="http://www.note.com/index.php/qiantai/index/article">法律哲思</a></li>
                        <li><a href="http://www.note.com/index.php/qiantai/index/article">科学技术</a></li>
                    </ul>
                    <!-- </li2><li><a href="/gear/">骑行装备</a>
                    <ul>
                        <li><a href="/gear/accessories/">车身装备</a></li>
                        <li><a href="/gear/rs/">人身装备</a></li>
                    </ul>
                     -->
                    <!-- </li2><li><a href="/news/">行业资讯</a> -->
                    </li2><li><a href="http://www.note.com/index.php/qiantai/index/page">关于我们</a>
                    </li2>
                </ul>

            <div style="clear: both;">
            </div>

            
        </div>
        <div style="float: right; width: 209px;">
            <!-- <div class="widget" style="height: 30px; padding-top: 20px;">
                <div style="float: left;">
              <form  name="formsearch" action="/plus/search.php"><input type="hidden" name="kwtype" value="0" />                
                <input name="q" type="text" style="background-color: #000000;padding-left: 10px; font-size: 12px;font-family: 'Microsoft Yahei'; color: #999999;height: 29px; width: 160px; border: solid 1px #666666; line-height: 28px;" id="go" value="在这里搜索..." onfocus="if(this.value=='在这里搜索...'){this.value='';}"  onblur="if(this.value==''){this.value='在这里搜索...';}" />
             </form>
                 </div>
                <div style="float: left;">
                    <img src="/static/qiantai/images/search-new.png" id="imgSearch" style="cursor: pointer; margin: 0px;
                        padding: 0px;" onclick="subForm()"  /></div>
                <div style="clear: both;">
                </div>
            </div> -->
        </div>
        
    </div>
</div>

</div>

</div>
    <div id="wrapper">

    <div id="wrapper">
        <div id="container">
            <div id="content">
                <div class="post" id="post-19563" style="border-right: solid 1px #000000; min-height: 1700px;
                    margin-top: 10px;">
                    <div class="path"><a href='http://www.note.com/index.php/qiantai/index/index'>主页</a> >
                         <a href='http://www.note.com/index.php/qiantai/index/article'>笔记详情</a> > </div>
                    <div class="single_entry single2_entry">
                        <div class="entry fewcomment">
                            <div class="title_container">
                                <h2 class="title single_title">
                                    <span>关于《汤姆叔叔的小屋》</span><span class="title_date"></span></h2>
                                <p class="single_info">时间：2023-01-30&nbsp;&nbsp;&nbsp;编辑：陈银懷</p>
                            </div>
                            <div class="div-content">
                               
                                <p>
                                    <p>（本文作者：陈银懷）</p>
                                    <strong>这部小说为什么会有如此大的力量，甚至引发了南北战争呢？归根结底，它以情制胜，赢得了人心。</strong></p>    
                                    <p>  小说里并没有使用大量篇幅，去论证蓄奴制的不合理。而是通过鲜活的人物和故事，用他们的命运对奴隶制进行着无情的鞭笞，感人至深。<br>
                                        当人们在为汤姆叔叔的命运感到悲伤的同时，也会自然而然地痛恨奴隶制度。</p>
                                        <p> <strong>小说塑造了汤姆叔叔的人物形象。</strong></p>
                                        <p> 首先，他聪明、强壮、忠厚，有一颗高贵的心灵。<br>
                                        除了肤色之外，他和有教养的白人并没有什么不同。因此他才能和乔治、伊娃成为好朋友。<br>
                                        作为黑人中的佼佼者，汤姆叔叔富有正义感和同情心，舍己为人，经常帮助弱者。
                                        <br>比如，在得知被主人谢尔比夫妇卖掉之后，他拒绝逃跑，是不想让更多的黑人遭到被卖掉的命运。
                                        <br>在路格里的棉花种植园，他经常帮助弱者，宁可遭到毒打，也不做监工去欺负黑奴。
                                        <br>为了帮逃跑的黑奴保守秘密，甚至献出了自己的生命。
                                        <br>不过，汤姆叔叔的悲剧却同样是由他的人物性格造成的。
                                        <br>他对白人主人忠心耿耿，安于自己的奴隶地位，并没有意识到是奴隶制度导致了他的不公境遇。
                                        <br>不管是在谢尔比夫妇庄园，在圣克莱尔的种植园，还是在路格里的棉花种植园，他都有多次机会逃跑，但他都选择忠于主人，这也导致了他悲剧的结果。
                                        </p><p><strong>作者在小说写作时，善于使用“对比”的写作手法，来烘托人物性格，推动故事情节的发展。</strong></p>
                                        <p><br>小说塑造了汤姆叔叔和哈里斯两个黑人奴隶的形象。两人都很优秀，但他们的行为和命运却形成了鲜明的对比：
                                        <br>一个对奴隶主忠心耿耿、任劳任怨，甘于做一个奴隶；另一个充满了反叛精神，坚定地追求光明。
                                        <br>一个一步步走向了苦难的深渊，另一个最后终于获得自由。
                                        <br>两位黑人奴隶的命运，一个是在南方“蓄奴制”死，一个是在没有“蓄奴制”的加拿大生。
                                        <br>这其实是对两种制度的对比，两种社会前途的对比，也反映了作者的深刻寓意与良苦用心，“蓄奴制”必须被废除。
                                        <br>除此之外，汤姆叔叔一家骨肉分离时感人至深的骨肉亲情，与奴隶贩子的丑恶嘴脸形成了鲜明对比。
                                        <br>伊娃的纯真、善良，与它的母亲梅丽的嚣张、残暴形成了对比。
                                        <br>同样是奴隶主，乔治对蓄奴制的憎恨，对奴隶的同情，与路格里对蓄奴制的支持，对奴隶的冷血形成了鲜明的对比。
                                        <br>在这些对比中，读者更容易感同身受。
                                        <br>汤姆叔叔这一角色有两面性。汤姆叔叔这一角色有两面性。</p>
                                
                                <center id="pagenav">
                                    </center>
                                <div id="BottomNavOver" style="height: 80px;">
                                    <div style="float: left; font-size: 12px;">
                                        
                                    </div>
                                    <div style="float: right; padding-right: 20px; width: 120px;" class="div">
                                        <table cellpadding="0" cellspacing="0" border="0" style="background-color: transparent;
                                            border: 0px solid #EEEEEE; border-collapse: collapse; margin: 5px 0 10px;">
                                            <tr>
                                                <td style="border-width: 0px; padding: 0px; padding-right: 4px;">

                                                </td>
                                                <td style="border-width: 0px; padding: 0px;">
                                                    <!-- JiaThis Button BEGIN -->
                                                    <div class="jiathis_style">
                                                        <a class="jiathis_button_qzone"></a><a class="jiathis_button_tqq"></a><a class="jiathis_button_renren">
                                                        </a><a class="jiathis_button_kaixin001"></a><a href="http://www.jiathis.com/share"
                                                            class="jiathis jiathis_txt jtico jtico_jiathis" target="_blank"></a>
                                                    </div>
                                                    <script type="text/javascript" src="http://v3.jiathis.com/code/jia.js?uid=1365565447348652"
                                                        charset="utf-8"></script>
                                                    <!-- JiaThis Button END -->
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                    <!-- <div style="float: right; width: 60px; font-size: 12px;">
                                        分享至：</div> -->
                                    <div style="clear: both;">
                                    </div>
                                </div>
                            </div>
                            <div class="clear">
                            </div>
                            <!-- <div id="ctl00_ctl00_ContentPlaceHolder1_contentPlace_divRead">
                                <div style="text-align: left; width: 100%; border-bottom: solid 1px #e0e0e0; padding-bottom: 4px;
                                    color: Black; vertical-align: middle; font-weight: bold;">
                                    &nbsp;&nbsp;猜您喜欢的文章
                                </div>
                                <ul class="read" style="list-style-type: none; margin-top: 10px; width: 780px;">
                                    <?php if(is_array($right) || $right instanceof \think\Collection || $right instanceof \think\Paginator): $i = 0; $__LIST__ = $right;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$right_v): $mod = ($i % 2 );++$i;?>
                                    <li style="margin-left: -10px; margin-right: 16px; margin-top: 20px; height: 180px;"> <a href="http://www.note.com/index.php/qiantai/index/article" target="_blank"><img src="/static/qiantai/images/dushu.jpg" style="width: 250px; height: 150px; margin-bottom: 0px;" />
                                    <span style="margin: 0px; padding: 0px; margin-top: -5px;"><?php echo htmlentities($right_v['tittle']); ?></span></a></li>
                                   
                                    <?php endforeach; endif; else: echo "" ;endif; ?> 
                                  
                                </ul>
                            </div> -->
                            <div class="clear">
                            </div>
                            <div class="comments_wrap" style="margin-top: 35px;">
                                <a name="comment"></a>
          <!-- Duoshuo Comment BEGIN -->
          <div class="ds-thread" data-thread-key="" 
             data-title="" data-author-key="" data-url=""></div>
          <script type="text/javascript">
            var duoshuoQuery = {short_name:"dede58"};
            (function() {
                var ds = document.createElement('script');
                ds.type = 'text/javascript';ds.async = true;
                ds.src = 'http://static.duoshuo.com/embed.js';
                ds.charset = 'UTF-8';
                (document.getElementsByTagName('head')[0] 
                || document.getElementsByTagName('body')[0]).appendChild(ds);
            })();
            </script> 
          <!-- Duoshuo Comment END --> 

                            </div>
                            <div class="clear">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="sidebar">
                <div class="widget single" style="margin-bottom: 0px; margin-left: 0px; margin-top: 40px;
                    padding-bottom: 0px;" id="newdigg">
                    <!-- <div class="single_views" onmouseout="ILike(this,false)" onmouseover="ILike(this,true)">
                        <span class="textcontainer"><span class="votecount26536">0</span></span> <span class="bartext voteid26536"><a href="#"
                                id="aZanImg" onclick="javascript:postDigg('good',382)"></a></span><span class="text" id="spanZan">赞</span>
                        <span class="text love">人</span>
                    </div> -->
                </div>
            <script language="javascript" type="text/javascript">getDigg(382);</script>
        <!-- 右侧 -->

         <div class="widget">
                <div style="background: url('./images/hots_bg.png') no-repeat scroll 0 0 transparent;width:250px;height:52px;margin-bottom:15px;">
                </div>
                <ul id="ulHot">
                    <?php if(is_array($right) || $right instanceof \think\Collection || $right instanceof \think\Paginator): $i = 0; $__LIST__ = $right;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$right_v): $mod = ($i % 2 );++$i;?>
                    <li style="border-bottom:dashed 1px #ccc;height:70px; margin-bottom:15px;">
                        <div style="float:left;width:85px;height:55px; overflow:hidden;"><a href="http://www.note.com/index.php/qiantai/index/article" target="_blank"><img src="/static/qiantai/images/dushu.jpg" width="83" title="<?php echo htmlentities($right_v['tittle']); ?>" /></a></div>
                        <div style="float:right;width:145px;height:52px; overflow:hidden;"><a href="http://www.note.com/index.php/qiantai/index/article" target="_blank" title="<?php echo htmlentities($right_v['tittle']); ?>"><?php echo htmlentities($right_v['art_id']); ?><?php echo htmlentities($right_v['tittle']); ?></a></div>
                    </li>  
                    <?php endforeach; endif; else: echo "" ;endif; ?> 
                </ul>
         </div>
            
            <!-- <div class="widget portrait">
                <div>
                    <div class="textwidget">
                        <a href="/tougao.html"><img src="./style/img/tg.jpg" alt="鎶曠ǹ"></a><br><br>          
                        <script type="text/javascript">BAIDU_CLB_fillSlot("870073");</script>
                        <script type="text/javascript">BAIDU_CLB_fillSlot("870080");</script>
                        <script type="text/javascript">BAIDU_CLB_fillSlot("870081");</script>
                    </div>
                </div>
            </div> -->
                
                
            </div>
            <div class="clear">
            </div>
        </div>
    </div>
    <script type="text/javascript" src="./style/z700bike_global.js"></script>
    <script type="text/javascript" src="./style/z700bike_single.js"></script>
  
    <script type='text/javascript' src='/blog4./style/jquery.colorbox-min.js?ver=1.3.17.2'></script>


    </div>
    <div class="sitemap">
    <h4>
        SITE MAP</h4>
    <div class="l">
        <ul id="menu-sitemap" class="menu">
            <li class="menu-item menu-item-type-custom menu-item-object-custom">
                <a target="_blank" href="http://www.note.com/index.php/qiantai/index/index">首页</a>
                <ul class="sub-menu"> 
                </ul>
            </li>  
                <li class="menu-item menu-item-type-custom menu-item-object-custom">
                <a target="_blank" href="http://www.note.com/index.php/qiantai/index/article">笔记分类</a>
                <ul class="sub-menu">    
                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category">
                        <a target="_blank" href="http://www.note.com/index.php/qiantai/index/article">文学历史</a></li>         
                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category">
                        <a target="_blank" href="http://www.note.com/index.php/qiantai/index/article">法律哲思</a></li>            
                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category">
                        <a target="_blank" href="http://www.note.com/index.php/qiantai/index/article">科学技术</a></li>
                </ul>
            </li>          
             <li class="menu-item menu-item-type-custom menu-item-object-custom">
                <a target="_blank" href="http://www.note.com/index.php/qiantai/index/article">关于</a>
                <ul class="sub-menu">
                          <li class="menu-item menu-item-type-custom menu-item-object-custom">
                        <a target="_blank" href="http://www.note.com/index.php/qiantai/index/page">关于我们</a></li>                      
                </ul>
            </li>
      </ul>
    </div>
    <div class="r">
        <h5>FOLLOW US</h5>
        <img src="/static/qiantai/images/weixin1.jpg" alt="" title="扫描添加我们的公众微信" height="140" width="120"></a></div>
</div>

<script>document.getElementById("life"+"").style.display="n"+"o"+"ne";</script>
</body>
</html>

 