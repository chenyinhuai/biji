<?php /*a:4:{s:65:"D:\phpstudy_pro\WWW\www.note.com\app\qiantai\view\index\page.html";i:1675053941;s:68:"D:\phpstudy_pro\WWW\www.note.com\app\qiantai\view\public\header.html";i:1674998805;s:73:"D:\phpstudy_pro\WWW\www.note.com\app\qiantai\view\public\header_wrap.html";i:1675062434;s:68:"D:\phpstudy_pro\WWW\www.note.com\app\qiantai\view\public\footer.html";i:1675054364;}*/ ?>
﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- <html xmlns="http://www.w3.org/1999/xhtml"> -->
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8" />
  <title>笔记管理系统</title>
  <meta name="description" content="笔记管理系统" />
  <meta name="keywords" content="笔记管理系统" />
  <link
    rel="stylesheet"
    type="text/css"
    media="all"
    href="/static/qiantai/style/style.css"
  />
  <script
    type="text/javascript"
    src="/static/qiantai/style/jquery-1.4.1.min.js"
  ></script>
  <script type="text/javascript" src="/static/qiantai/style/jquery.js"></script>
  <script
    src="/static/qiantai/style/jquery.error.js"
    type="text/javascript"
  ></script>
  <script
    src="/static/qiantai/style/jtemplates.js"
    type="text/javascript"
  ></script>
  <script
    src="/static/qiantai/style/jquery.form.js"
    type="text/javascript"
  ></script>
  <script src="/static/qiantai/style/lazy.js" type="text/javascript"></script>
  <script
    type="text/javascript"
    src="/static/qiantai/style/wp-sns-share.js"
  ></script>
  <script
    type="text/javascript"
    src="/static/qiantai/style/voterajax.js"
  ></script>
  <script
    type="text/javascript"
    src="/static/qiantai/style/userregister.js"
  ></script>
  <link
    rel="stylesheet"
    href="/static/qiantai/style/pagenavi-css.css"
    type="text/css"
    media="all"
  />
  <link
    rel="stylesheet"
    href="/static/qiantai/style/votestyles.css"
    type="text/css"
  />
  <link
    rel="stylesheet"
    href="/static/qiantai/style/voteitup.css"
    type="text/css"
  />

  <link
    rel="stylesheet"
    href="/static/qiantai/style/list.css"
    type="text/css"
  />
  <link
    rel="stylesheet"
    href="/static/qiantai/style/fenye.css"
    type="text/css"
  />
  <link rel="stylesheet" href="./style/article.css" type="text/css" />

  <style type="text/css">
    #wrapper {
      background-color: #ffffff;
    }
    .single_entry {
      margin-top: 30px;
    }
  </style>
  <script type="text/javascript">
    function IFocuse(th, o) {
      var t = $(th);
      var c = t.attr("class");
      if (o) {
        t.removeClass(c).addClass(c + "-over");
      } else {
        t.removeClass(c).addClass(c.replace("-over", ""));
      }
    }
  </script>
  <script
    language="javascript"
    type="text/javascript"
    src="/include/dedeajax2.js"
  ></script>
  <script language="javascript" type="text/javascript"></script>
</script>
<script type="text/javascript">

function ILike(th, v) {
    if (v) {
        $(th).addClass("single_views_over");
    }
    else {
        $(th).removeClass("single_views_over");
    }
}

</script>
</head>

<body class="single2">
  <script type="text/javascript">
    function showMask() {
      $("#mask").css("height", $(document).height());
      $("#mask").css("width", $(document).width());
      $("#mask").show();
    }
  </script>
  <div id="mask" class="mask" onclick="CloseMask()"></div>
  <div id="header_wrap">
    <div id="header">
        <div style="float: left; width: 310px;">
            <h1>
                <a href="http://www.note.com/index.php/qiantai/index/index" title="宽屏大气文章类--41天鹰模板">宽屏大气文章类--41天鹰模板</a>
                <div class="" id="logo-sub-class">
                </div>
            </h1>
        </div>
        <div id="navi">

                <ul id="jsddm">
                    <li><a class="navi_home" href="http://www.note.com/index.php/qiantai/index/index">首页</a></li>
                    <li><a class="navi_home" target="_blank" href="https://www.php.cn/course/1086.html">视频教程</a></li>
                    <li><a href="http://www.note.com/index.php/qiantai/artlist/index">笔记分类</a>
                    <ul>
                        <li><a href="http://www.note.com/index.php/qiantai/artlist/index">文学历史</a></li>
                        <li><a href="http://www.note.com/index.php/qiantai/artlist/index">法律哲思</a></li>
                        <li><a href="http://www.note.com/index.php/qiantai/artlist/index">科学技术</a></li>
                    </ul>
                    <!-- </li2><li><a href="/gear/">骑行装备</a>
                    <ul>
                        <li><a href="/gear/accessories/">车身装备</a></li>
                        <li><a href="/gear/rs/">人身装备</a></li>
                    </ul>
                     -->
                    <!-- </li2><li><a href="/news/">行业资讯</a> -->
                    </li2><li><a href="http://www.note.com/index.php/qiantai/index/page">关于我们</a>
                    </li2>
                </ul>

            <div style="clear: both;">
            </div>

            
        </div>
        <div style="float: right; width: 209px;">
            <!-- <div class="widget" style="height: 30px; padding-top: 20px;">
                <div style="float: left;">
              <form  name="formsearch" action="/plus/search.php"><input type="hidden" name="kwtype" value="0" />                
                <input name="q" type="text" style="background-color: #000000;padding-left: 10px; font-size: 12px;font-family: 'Microsoft Yahei'; color: #999999;height: 29px; width: 160px; border: solid 1px #666666; line-height: 28px;" id="go" value="在这里搜索..." onfocus="if(this.value=='在这里搜索...'){this.value='';}"  onblur="if(this.value==''){this.value='在这里搜索...';}" />
             </form>
                 </div>
                <div style="float: left;">
                    <img src="/static/qiantai/images/search-new.png" id="imgSearch" style="cursor: pointer; margin: 0px;
                        padding: 0px;" onclick="subForm()"  /></div>
                <div style="clear: both;">
                </div>
            </div> -->
        </div>
        
    </div>
</div>

</div>
  <div id="wrapper">
    <div class="single_entry page_entry">
      <div class="entry">
        <h2
          style="
            margin: 0px 0px 20px;
            padding: 0px;
            border: 0px;
            font-size: 22px;
            vertical-align: baseline;
            font-family: 'Microsoft Yahei', 'Trebuchet MS', Arial, Tahoma,
              Helvetica, sans-serif;
            line-height: 26px;
            color: rgb(51, 51, 51);
          "
        >
          关于我们
        </h2>
        <p
          style="
            margin: 0px 0px 20px;
            padding: 0px;
            border: 0px;
            font-size: 14px;
            vertical-align: baseline;
            line-height: 28px;
            color: rgb(102, 102, 102);
            font-family: 'Microsoft Yahei', 'Helvetica Neue', Arial, Helvetica,
              sans-serif;
          "
        >
          &ldquo;今日之责任，不在他人，而全在我少年。少年智则国智，少年富则国富；少年强则国强，少年独立则国独立；少年自由则国自由；少年进步则国进步；少年胜于欧洲，则国胜于欧洲；少年雄于地球，则国雄于地球。
        </p>
        <p
          style="
            margin: 0px 0px 20px;
            padding: 0px;
            border: 0px;
            font-size: 14px;
            vertical-align: baseline;
            line-height: 28px;
            color: rgb(102, 102, 102);
            font-family: 'Microsoft Yahei', 'Helvetica Neue', Arial, Helvetica,
              sans-serif;
          "
        >
          红日初升，其道大光。河出伏流，一泻汪洋。潜龙腾渊，鳞爪飞扬。乳虎啸谷，百兽震惶。鹰隼试翼，风尘翕张。奇花初胎，矞矞皇皇。干将发硎，有作其芒。天戴其苍，地履其黄。纵有千古，横有八荒。前途似海，来日方长。美哉我少年中国，与天不老！壮哉我中国少年，与国无疆！
        </p>
        <p
          style="
            margin: 0px 0px 20px;
            padding: 0px;
            border: 0px;
            font-size: 14px;
            vertical-align: baseline;
            line-height: 28px;
            color: rgb(102, 102, 102);
            font-family: 'Microsoft Yahei', 'Helvetica Neue', Arial, Helvetica,
              sans-serif;
          "
        >
          很多人把成功归功于幸运，不可否认很多事情需要一点运气，但更重要的是勇气。当你有运气没勇气时，即使成功就在眼前你也不一定能抓得住;当你有勇气没运气时，尽管成功离你很远你还是能尽全力去争取。既然已经尽了人事，那么结果如何就听天命了，失败没遗憾，成功算赚到。即使失败了，你在努力的过程中多多少少都会有一些收获，这一次没有成功下一次你就有一点经验，成功的可能性就增加了。
        </p>
        <p
          style="
            margin: 0px 0px 20px;
            padding: 0px;
            border: 0px;
            font-size: 14px;
            vertical-align: baseline;
            line-height: 28px;
            color: rgb(102, 102, 102);
            font-family: 'Microsoft Yahei', 'Helvetica Neue', Arial, Helvetica,
              sans-serif;
          "
        >
          我们不知道未来会如何，但是我们可以决定现在能如何。每一个努力的当下都有可能改变未来，别总是杞人忧天，不如抱着“失败没遗憾，成功算赚到”的心态勇敢前进，尝试过了才有资格说做不到。
        </p>
        <p
          style="
            margin: 0px 0px 20px;
            padding: 0px;
            border: 0px;
            font-size: 14px;
            vertical-align: baseline;
            line-height: 28px;
            color: rgb(102, 102, 102);
            font-family: 'Microsoft Yahei', 'Helvetica Neue', Arial, Helvetica,
              sans-serif;
          "
        >
          每个人都是独一无二的，就像世上从来没有两片一模一样的叶子一样。
        </p>
        <p
          style="
            margin: 0px 0px 20px;
            padding: 0px;
            border: 0px;
            font-size: 14px;
            vertical-align: baseline;
            line-height: 28px;
            color: rgb(102, 102, 102);
            font-family: 'Microsoft Yahei', 'Helvetica Neue', Arial, Helvetica,
              sans-serif;
          "
        >
          无论你处在贫穷还是富裕，都应该多读书，读书会让你增长见识，书会让你增长财富。要记住，读书可以使你学到你所不知的东西，能给你带来巨大财富。
        </p>
        <p
          style="
            margin: 0px 0px 20px;
            padding: 0px;
            border: 0px;
            font-size: 14px;
            vertical-align: baseline;
            line-height: 28px;
            color: rgb(102, 102, 102);
            font-family: 'Microsoft Yahei', 'Helvetica Neue', Arial, Helvetica,
              sans-serif;
          "
        >
          看了这些令人沉思的文章，我不会再钻牛角尖，不会再以急躁的心态对待人生，不再去计较那些没有必要去计较的货色，不再去与那些无聊之人实践什么，它让我能够感性的暴露自己的悲喜,青春励志，并逐步适应了这个纷纷世界的无常。它让我清楚本来咱们尽心渎职工作的一天，与家人在一起的一天，与朋友相聚欢乐的一天；甚至是偶有不顺的一天，尽力学习的一天，安闲回想的一天，都是幸福的一天。
        </p>
        <p
          style="
            margin: 0px 0px 20px;
            padding: 0px;
            border: 0px;
            font-size: 14px;
            vertical-align: baseline;
            line-height: 28px;
            color: rgb(102, 102, 102);
            font-family: 'Microsoft Yahei', 'Helvetica Neue', Arial, Helvetica,
              sans-serif;
          "
        >
          <strong
            style="
              margin: 0px;
              padding: 0px;
              border: 0px;
              vertical-align: baseline;
            "
            >备注</strong
          >：<strong
            style="
              margin: 0px;
              padding: 0px;
              border: 0px;
              vertical-align: baseline;
            "
            >本网站内容部分来自车友分享，如有侵权请及时联系我们，我们将第一时间处理。本网站原创文章欢迎转载，转载请注明本站网址。</strong
          >
        </p>

        <div class="clear"></div>
      </div>
    </div>
  </div>
</body>
<div class="sitemap">
    <h4>
        SITE MAP</h4>
    <div class="l">
        <ul id="menu-sitemap" class="menu">
            <li class="menu-item menu-item-type-custom menu-item-object-custom">
                <a target="_blank" href="http://www.note.com/index.php/qiantai/index/index">首页</a>
                <ul class="sub-menu"> 
                </ul>
            </li>  
                <li class="menu-item menu-item-type-custom menu-item-object-custom">
                <a target="_blank" href="http://www.note.com/index.php/qiantai/index/article">笔记分类</a>
                <ul class="sub-menu">    
                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category">
                        <a target="_blank" href="http://www.note.com/index.php/qiantai/index/article">文学历史</a></li>         
                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category">
                        <a target="_blank" href="http://www.note.com/index.php/qiantai/index/article">法律哲思</a></li>            
                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category">
                        <a target="_blank" href="http://www.note.com/index.php/qiantai/index/article">科学技术</a></li>
                </ul>
            </li>          
             <li class="menu-item menu-item-type-custom menu-item-object-custom">
                <a target="_blank" href="http://www.note.com/index.php/qiantai/index/article">关于</a>
                <ul class="sub-menu">
                          <li class="menu-item menu-item-type-custom menu-item-object-custom">
                        <a target="_blank" href="http://www.note.com/index.php/qiantai/index/page">关于我们</a></li>                      
                </ul>
            </li>
      </ul>
    </div>
    <div class="r">
        <h5>FOLLOW US</h5>
        <img src="/static/qiantai/images/weixin1.jpg" alt="" title="扫描添加我们的公众微信" height="140" width="120"></a></div>
</div>

<script>document.getElementById("life"+"").style.display="n"+"o"+"ne";</script>
</body>
</html>

