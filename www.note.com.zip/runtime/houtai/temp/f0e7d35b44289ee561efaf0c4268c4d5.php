<?php /*a:1:{s:63:"D:\phpstudy_pro\WWW\www.note.com\app\houtai\view\user\edit.html";i:1675013721;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <tittle></tittle>
    <link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css">
    <script type="text/javascript" src="/static/layui/layui.js"></script>
</head>
<body style="padding:10px;">
    <form class="layui-form">
        <input type="hidden" name="user_id" value="<?php echo htmlentities($shop['user_id']); ?>">
        <div class="layui-form-item">
            <label class="layui-form-label">用户名</label>
            <div class="layui-input-inline">
                <input type="text" class="layui-input" name="username" value="<?php echo htmlentities($shop['username']); ?>">
            </div>
        </div>
        <div class="layui-form-item">
          <label class="layui-form-label">密码</label>
          <div class="layui-input-inline">
              <input type="text" class="layui-input" name="password" value="<?php echo htmlentities($shop['password']); ?>">
          </div>
      </div>

    <div class="layui-form-item">
      <label class="layui-form-label">上次登陆时间</label>
      <div class="layui-input-inline">
          <input type="date" class="layui-input" name="lastlogin" value="<?php echo htmlentities($shop['lastlogin']); ?>">
      </div>
  </div>
        <div class="layui-form-item">
            <label class="layui-form-label">状态</label>
            <div class="layui-input-inline">
                <select name="status">
                    <option value="1" <?php if($shop['status']==1): ?> selected <?php endif; ?>>开启</option>
                    <option value="2" <?php if($shop['status']==2): ?> selected <?php endif; ?>>关闭</option>
                </select>
            </div>
        </div>
    </form>

    <div class="layui-form-item">
        <div class="layui-input-block">
            <button class="layui-btn" onclick="save()">保存</button>
        </div>
    </div>



    <script type="text/javascript">
        layui.use(['layer','form'],function(){
            form = layui.form;
            layer = layui.layer;
            $ = layui.jquery;
        });
        function save(){
            $.post('/index.php/houtai/Article/edits',$('form').serialize(),function(res){
                if(res.code>0){
                    layer.alert(res.msg,{icon:2});
                }else{
                    layer.msg(res.msg);
                    setTimeout(function(){parent.window.location.reload();},1000);
                }
            },'json');
        }
    </script>
</body>
</html>