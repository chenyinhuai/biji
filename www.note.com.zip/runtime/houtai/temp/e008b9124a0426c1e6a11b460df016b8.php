<?php /*a:1:{s:63:"D:\phpstudy_pro\WWW\www.note.com\app\houtai\view\index\add.html";i:1674992089;}*/ ?>
﻿<!DOCTYPE html>
<html>
  <head>
    <tittle></tittle>
    <link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css" />
    <script type="text/javascript" src="/static/layui/layui.js"></script>
  </head>
  <body style="padding: 10px">
    <form class="layui-form">
      <div class="layui-form-item">
        <label class="layui-form-label">标题</label>
        <div class="layui-input-inline">
          <input type="text" class="layui-input" name="tittle" value="" />
        </div>
      </div>

      <div class="layui-form-item">
        <label class="layui-form-label">内容</label>
        <div class="layui-input-inline">
          <input type="text" class="layui-input" name="content" value="" />
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">作者</label>
        <div class="layui-input-inline">
          <input type="text" class="layui-input" name="author" value="" />
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">分类</label>
        <div class="layui-input-inline">
          <input type="text" class="layui-input" name="cat_id" value="" />
        </div>
      </div>

      <div class="layui-form-item">
        <label class="layui-form-label">用户id</label>
        <div class="layui-input-inline">
          <input type="text" class="layui-input" name="user_id" value="" />
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">昵称</label>
        <div class="layui-input-inline">
          <input type="text" class="layui-input" name="nick" value="" />
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">发布时间</label>
        <div class="layui-input-inline">
          <input type="date" class="layui-input" name="pubtime" value="" />
        </div>
      </div>

      <div class="layui-form-item">
        <label class="layui-form-label">更新时间</label>
        <div class="layui-input-inline">
          <input type="date" class="layui-input" name="lastup" value="" />
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">状态</label>
        <div class="layui-input-inline">
          <select name="status">
            <option value="1">开启</option>
            <option value="0">关闭</option>
          </select>
        </div>
      </div>
    </form>

    <div class="layui-form-item">
      <div class="layui-input-block">
        <button class="layui-btn" onclick="save()">保存</button>
      </div>
    </div>
    <script type="text/javascript">
      layui.use(["layer", "form"], function () {
        form = layui.form;
        layer = layui.layer;
        $ = layui.jquery;
      });
      function save() {
        $.post(
          "/index.php/houtai/Index/add",
          $("form").serialize(),
          function (res) {
            if (res.code > 0) {
              layer.alert(res.msg, { icon: 2 });
            } else {
              layer.msg(res.msg);
              setTimeout(function () {
                parent.window.location.reload();
              }, 1000);
            }
          },
          "json"
        );
      }
    </script>
  </body>
</html>
