<?php /*a:1:{s:64:"D:\phpstudy_pro\WWW\www.note.com\app\houtai\view\test\index.html";i:1674887435;}*/ ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
  </head>

  <body>
    <?php if($status == 1): ?>
    <div>允许操作</div>
    <?php else: ?>
    <div>不允许操作</div>
    <?php endif; if($order_status == 0): ?>
    <div>未支付</div>
    <?php elseif($order_status == 1): ?>
    <div>已支付 待发货</div>
    <?php elseif($order_status == 2): ?>
    <div>已发货 待收货</div>
    <?php elseif($order_status == 3): ?>
    <div>已收货 待评论</div>
    <?php elseif($order_status == 4): ?>
    <div>已完成</div>
    <?php endif; switch($order_status): case "0": ?>
    <div>未支付</div>
    <?php break; case "1": ?>
    <div>已支付 待发货</div>
    <?php break; case "2": ?>
    <div>已发货 待收货</div>
    <?php break; case "3": ?>
    <div>已收货 待评论</div>
    <?php break; case "4": ?>
    <div>已完成</div>
    <?php break; ?> <?php endswitch; ?>
  </body>
</html>
