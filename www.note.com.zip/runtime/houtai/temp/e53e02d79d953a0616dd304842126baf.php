<?php /*a:5:{s:64:"D:\phpstudy_pro\WWW\www.note.com\app\houtai\view\user\index.html";i:1675013321;s:67:"D:\phpstudy_pro\WWW\www.note.com\app\houtai\view\public\header.html";i:1675004681;s:66:"D:\phpstudy_pro\WWW\www.note.com\app\houtai\view\public\toubu.html";i:1675010849;s:65:"D:\phpstudy_pro\WWW\www.note.com\app\houtai\view\public\left.html";i:1675014245;s:72:"D:\phpstudy_pro\WWW\www.note.com\app\houtai\view\public\BasicScript.html";i:1674890966;}*/ ?>
<!DOCTYPE html>

<head>
  <meta charset="utf-8" />
  <title>笔记管理系统</title>

  <meta name="description" content="Dashboard" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css" />
  <script type="text/javascript" src="/static/layui/layui.js"></script>
  <!--Basic Styles-->
  <link
    href="/static/houtai/style/bootstrap.css"
    rel="stylesheet"
    type="text/css"
  />
  <link
    href="/static/houtai/style/font-awesome.css"
    rel="stylesheet"
    type="text/css"
  />
  <link
    href="/static/houtai/style/weather-icons.css"
    rel="stylesheet"
    type="text/css"
  />

  <!--Beyond styles-->
  <link
    id="beyond-link"
    href="/static/houtai/style/beyond.css"
    rel="stylesheet"
    type="text/css"
  />
  <link href="/static/houtai/style/demo.css" rel="stylesheet" type="text/css" />
  <link
    href="/static/houtai/style/typicons.css"
    rel="stylesheet"
    type="text/css"
  />
  <link
    href="/static/houtai/style/animate.css"
    rel="stylesheet"
    type="text/css"
  />
  <link
    href="/static/houtai/style/fenye.css"
    rel="stylesheet"
    type="text/css"
  />
</head>

<body>
    <!-- 头部 -->
<div class="navbar">
  <div class="navbar-inner">
    <div class="navbar-container">
      <!-- Navbar Barnd -->
      <div class="navbar-header pull-left">
        <a href="#" class="navbar-brand">
          <small>
            <img src="/static/houtai/images/logo.png" alt="" />
          </small>
        </a>
      </div>
      <!-- /Navbar Barnd -->
      <!-- Sidebar Collapse -->
      <div class="sidebar-collapse" id="sidebar-collapse">
        <i class="collapse-icon fa fa-bars"></i>
      </div>
      <!-- /Sidebar Collapse -->
      <!-- Account Area and Settings -->
      <div class="navbar-header pull-right">
        <div class="navbar-account">
          <ul class="account-area">
            <li>
              <a class="login-area dropdown-toggle" data-toggle="dropdown">
                <div class="avatar" title="View your public profile">
                  <img src="/static/houtai/images/adam-jansen.jpg" />
                </div>
                <section>
                  <h2>
                    <span class="profile"><span><?php echo htmlentities($username); ?></span></span>
                  </h2>
                </section>
              </a>
              <!--Login Area Dropdown-->
              <ul
                class="pull-right dropdown-menu dropdown-arrow dropdown-login-area"
              >
                <li class="username"><a>David Stevenson</a></li>
                <li class="dropdown-footer">
                  <a href="/admin/user/logout.html"> 退出登录 </a>
                </li>
                <li class="dropdown-footer">
                  <a href="/admin/user/changePwd.html"> 修改密码 </a>
                </li>
              </ul>
              <!--/Login Area Dropdown-->
            </li>
            <!-- /Account Area -->
            <!--Note: notice that setting div must start right after account area list.
                            no space must be between these elements-->
            <!-- Settings -->
          </ul>
        </div>
      </div>
      <!-- /Account Area and Settings -->
    </div>
  </div>
</div>

<!-- /头部 -->
	
	<div class="main-container container-fluid">
		<div class="page-container">
            <!-- Page Sidebar -->
<div class="page-sidebar" id="sidebar">
  <!-- Page Sidebar Header-->
  <div class="sidebar-header-wrapper">
    <input class="searchinput" type="text" />
    <i class="searchicon fa fa-search"></i>
    <div class="searchhelper">
      Search Reports, Charts, Emails or Notifications
    </div>
  </div>
  <!-- /Page Sidebar Header -->
  <!-- Sidebar Menu -->
  <ul class="nav sidebar-menu">
    <!--Dashboard-->
    <li>
      <a
        href="http://www.note.com/index.php/qiantai/index/index"
        target="_blank"
        class="menu-dropdown"
      >
        <i class="menu-icon fa fa-user"></i>
        <span class="menu-text"><?php if($tittle): ?><?php echo htmlentities($tittle); ?><?php endif; ?></span>
        <i class="menu-expand"></i>
      </a>
    </li>
    <!-- 此处用循环挺好，但是我懒得再在数据库里加链接了，就这样吧 -->
    <!-- <?php foreach($left as $v): ?>
    <li>
      <a
        href="http://www.note.com/index.php/houtai/article/index/article.html"
        class="menu-dropdown"
      >
        <i class="menu-icon fa fa-user"></i>
        <span class="menu-text"><?php echo htmlentities($v['tittle']); ?></span>
        <i class="menu-expand"></i>
      </a>
      <?php foreach($v['lists'] as $vv): ?>
      <ul class="submenu">
        <li>
          <a href="index/article.html">
            <span class="menu-text"> <?php echo htmlentities($vv['tittle']); ?> </span>

            <i class="menu-expand"></i>
          </a>
        </li>
      </ul>
      <?php endforeach; ?>
    </li>
    <?php endforeach; ?> -->
    <li>
      <a
        href="http://www.note.com/index.php/houtai/article/index"
        class="menu-dropdown"
      >
        <i class="menu-icon fa fa-user"></i>
        <span class="menu-text">文档管理</span>
        <i class="menu-expand"></i>
      </a>
     
      <ul class="submenu">
        <li>
          <a href="http://www.note.com/index.php/houtai/article/index">
            <span class="menu-text"> 文档列表</span>

            <i class="menu-expand"></i>
          </a>
        </li>
      </ul>
    </li>
    
    <li>
      <a
        href="http://www.note.com/index.php/houtai/user/index"
        class="menu-dropdown"
      >
        <i class="menu-icon fa fa-user"></i>
        <span class="menu-text">用户管理</span>
        <i class="menu-expand"></i>
      </a>
     
      <ul class="submenu">
        <li>
          <a href="http://www.note.com/index.php/houtai/user/index">
            <span class="menu-text"> 用户列表</span>

            <i class="menu-expand"></i>
          </a>
        </li>
      </ul>
    </li>
  <!-- /Sidebar Menu -->
</div>
<!-- /Page Sidebar -->

            <!-- Page Content -->
            <div class="page-content">
                <!-- Page Breadcrumb -->
                <div class="page-breadcrumbs">
                    <ul class="breadcrumb">
                     <li class="active">用户管理</li>
                     </ul>
                </div>
                <!-- /Page Breadcrumb -->
                <!-- Page Body -->
                <div class="row">
                    <div class="col-lg-12 col-sm-12 col-xs-12">
                        <div class="widget">
                            <div class="widget-body">
                                <div class="flip-scroll">
                                    <table class="table table-bordered table-hover">
                                            <tr>
                                                <th class="text-left">用户列表</th>
                                                <th class="text-right"><button class="layui-btn layui-btn-xs " onclick="add()">添加</button></th>
                                            </tr>
                                    </table>
                                    <form class="layui-form" method="post">
                                        <div class="layui-form-item" style="margin-top:10px;">
                                            <div class="layui-input-inline">
                                                <select name="status">
                                                    <option value="0" <?php if($status==0): ?>selected<?php endif; ?>>全部</option>
                                                    <option value="1" <?php if($status==1): ?>selected<?php endif; ?>>开启</option>
                                                    <option value="2" <?php if($status==2): ?>selected<?php endif; ?>>关闭</option>
                                                </select>
                                            </div>
                                            <button class="layui-btn layui-btn-primary"><i class="layui-icon">&#xe615;</i>搜索</button>
                                        </div>
                                    </form>
                                    <table class="table table-bordered table-hover">
                                        <thead class="">
                                            <tr>
                                                <th class="text-center">ID</th>
                                                <th class="text-center">用户名</th>
                                                <th class="text-center">密码</th>
                                                <th class="text-center">上次登陆时间</th>                                           
                                                <th class="text-center">状态</th>
                                                <th class="text-center">操作1</th>
                                                <th class="text-center">操作2</th>
                                            </tr>
                                        </thead>                                      
                        <tbody>
                            <?php if(is_array($right) || $right instanceof \think\Collection || $right instanceof \think\Paginator): $i = 0; $__LIST__ = $right;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$right_v): $mod = ($i % 2 );++$i;?>
                                <tr>
                                    <td align="center"><?php echo htmlentities($right_v['user_id']); ?></td>
                                    <td align="center"><?php echo htmlentities($right_v['username']); ?></td>
                                    <td align="center"><?php echo htmlentities($right_v['password']); ?></td>
                                    <td align="center"><?php echo htmlentities(date('Y-m-d',!is_numeric($right_v['lastlogin'])? strtotime($right_v['lastlogin']) : $right_v['lastlogin'])); ?></td>                             
                                    <td align="center"><?php if($right_v['status']==1): ?>开启<?php elseif($right_v['status']==2): ?>关闭<?php elseif($right_v['status']==3): ?>删除<?php endif; ?></td>    
                                    <td align="center"><button class="layui-btn layui-btn-xs" onclick="edit(<?php echo htmlentities($right_v['user_id']); ?>)">编辑</button></td>    
                                    <td align="center"><button class="layui-btn layui-btn-xs" onclick="del(<?php echo htmlentities($right_v['user_id']); ?>)">删除</button></td>                                                          
                                </tr>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </tbody>
                       
                    </table>      
                    <!-- 其实有更简单的模板分页 -->
                    <div class="layui-box layui-laypage layui-laypage-default ">
                        <a href="/index.php/houtai/Article/index?p=<?php echo htmlentities($p-1); ?>&status=<?php echo htmlentities($status); ?>" class="layui-laypage-prev <?php if($p<=1): ?>layui-disabled<?php endif; ?>">上一页</a>
                        <?php $__FOR_START_1506461922__=0;$__FOR_END_1506461922__=$count;for($i=$__FOR_START_1506461922__;$i < $__FOR_END_1506461922__;$i+=1){ if($p == $i+1): ?>
                                <span class="layui-laypage-curr">
                                    <em class="layui-laypage-em"></em>
                                    <em><?php echo htmlentities($i+1); ?></em>
                                </span>
                            <?php else: ?>
                                <a href="/index.php/houtai/Article/index?p=<?php echo htmlentities($i+1); ?>&status=<?php echo htmlentities($status); ?>"><?php echo htmlentities($i+1); ?></a>
                            <?php endif; } ?>
                        <a href="/index.php/houtai/Article/index?p=<?php echo htmlentities($p+1); ?>&status=<?php echo htmlentities($status); ?>" class="layui-laypage-next <?php if($p>=$count): ?>layui-disabled<?php endif; ?>">下一页</a>
                    </div>      


                    
                </div>
                </div>      
                </div>
                <!-- /Page Body -->
            </div>
            <!-- /Page Content -->
		</div>	
	</div>
    <!--Basic Scripts-->
<script src="/static/houtai/style/jquery_002.js"></script>
<script src="/static/houtai/style/bootstrap.js"></script>
<script src="/static/houtai/style/jquery.js"></script>
<!--Beyond Scripts-->
<script src="/static/houtai/style/beyond.js"></script>

</body></html>
<script type="text/javascript">
    function edit(user_id){
        layer.open({
            type: 2,
            title: '修改',
            shade: 0.3,
            area: ['480px', '440px'],
            content: '/index.php/houtai/User/edit?user_id='+user_id
        });
    }
    function add(){
        layer.open({
            type: 2,
            title: '添加',
            shade: 0.3,
            area: ['480px', '440px'],
            content: '/index.php/houtai/user/add'
        });
    }
    function del(user_id){
        layer.confirm('确定要删除吗？', {
            icon:3,
            btn: ['确定','取消']
        }, function(){
            $.post('/index.php/houtai/user/del',{'user_id':user_id},function(res){
                if(res.code>0){
                    layer.alert(res.msg,{icon:2});
                }else{
                    layer.msg(res.msg);
                    setTimeout(function(){window.location.reload();},1000);
                }
            },'json');
        });
    }
</script>