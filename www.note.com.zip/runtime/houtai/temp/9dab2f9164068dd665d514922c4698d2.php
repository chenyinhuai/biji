<?php /*a:2:{s:65:"D:\phpstudy_pro\WWW\www.note.com\app\houtai\view\login\index.html";i:1675008276;s:72:"D:\phpstudy_pro\WWW\www.note.com\app\houtai\view\public\BasicScript.html";i:1674890966;}*/ ?>
﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
  <!--Head--><head>
    <meta charset="utf-8" />
    <title>系统登录</title>
    <meta name="description" content="login page" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <!--Basic Styles-->
    <link href="/static/houtai/style/bootstrap.css" rel="stylesheet" />
    <link href="/static/houtai/style/font-awesome.css" rel="stylesheet" />
    <!--Beyond styles-->
    <link
      id="beyond-link"
      href="/static/houtai/style/beyond.css"
      rel="stylesheet"
    />
    <link href="/static/houtai/style/demo.css" rel="stylesheet" />
    <link href="/static/houtai/style/animate.css" rel="stylesheet" />
  </head>
  <!--Head Ends-->
  <!--Body-->

  <body>
    <div class="login-container animated fadeInDown">
      <form action="" method="post">
        <div class="loginbox bg-white">
          <div class="loginbox-title">SIGN IN</div>
          <div class="loginbox-textbox">
            <input
              value="admin"
              class="form-control"
              placeholder="username"
              name="username"
              type="text"
            />
          </div>
          <div class="loginbox-textbox">
            <input
              class="form-control"
              placeholder="password"
              name="password"
              type="password"
            />
          </div>
          <div class="loginbox-submit">
            <input
              class="btn btn-primary btn-block"
              value="Login"
              type="submit"
            />
          </div>
        </div>
        <div class="logobox">
          <p class="text-center">系统登录</p>
        </div>
        <!-- <h2 class="text_center mar_b_30">后台登录</h2>
        <div class="layui-form-item">
          <input
            type="text"
            name="username"
            required
            lay-verify="required"
            placeholder="请输入用户名"
            autocomplete="off"
            class="layui-input"
          />
        </div>
        <div class="layui-form-item">
          <input
            type="password"
            name="password"
            required
            lay-verify="required"
            placeholder="请输入密码"
            autocomplete="off"
            class="layui-input"
          />
        </div>

        <div class="layui-form-item text_center mar_t_30">
          <button class="layui-btn" type="submit">立即提交</button>
        </div> -->
      </form>
    </div>
    <!--Basic Scripts-->
<script src="/static/houtai/style/jquery_002.js"></script>
<script src="/static/houtai/style/bootstrap.js"></script>
<script src="/static/houtai/style/jquery.js"></script>
<!--Beyond Scripts-->
<script src="/static/houtai/style/beyond.js"></script>

  </body>
  <!--Body Ends-->
</html>
