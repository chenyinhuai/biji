<?php /*a:5:{s:65:"D:\phpstudy_pro\WWW\www.note.com\app\houtai\view\index\index.html";i:1675011098;s:67:"D:\phpstudy_pro\WWW\www.note.com\app\houtai\view\public\header.html";i:1675004681;s:66:"D:\phpstudy_pro\WWW\www.note.com\app\houtai\view\public\toubu.html";i:1675010849;s:65:"D:\phpstudy_pro\WWW\www.note.com\app\houtai\view\public\left.html";i:1675014245;s:72:"D:\phpstudy_pro\WWW\www.note.com\app\houtai\view\public\BasicScript.html";i:1674890966;}*/ ?>
﻿<!DOCTYPE html>

<head>
  <meta charset="utf-8" />
  <title>笔记管理系统</title>

  <meta name="description" content="Dashboard" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css" />
  <script type="text/javascript" src="/static/layui/layui.js"></script>
  <!--Basic Styles-->
  <link
    href="/static/houtai/style/bootstrap.css"
    rel="stylesheet"
    type="text/css"
  />
  <link
    href="/static/houtai/style/font-awesome.css"
    rel="stylesheet"
    type="text/css"
  />
  <link
    href="/static/houtai/style/weather-icons.css"
    rel="stylesheet"
    type="text/css"
  />

  <!--Beyond styles-->
  <link
    id="beyond-link"
    href="/static/houtai/style/beyond.css"
    rel="stylesheet"
    type="text/css"
  />
  <link href="/static/houtai/style/demo.css" rel="stylesheet" type="text/css" />
  <link
    href="/static/houtai/style/typicons.css"
    rel="stylesheet"
    type="text/css"
  />
  <link
    href="/static/houtai/style/animate.css"
    rel="stylesheet"
    type="text/css"
  />
  <link
    href="/static/houtai/style/fenye.css"
    rel="stylesheet"
    type="text/css"
  />
</head>

<body>
    <!-- 头部 -->
<div class="navbar">
  <div class="navbar-inner">
    <div class="navbar-container">
      <!-- Navbar Barnd -->
      <div class="navbar-header pull-left">
        <a href="#" class="navbar-brand">
          <small>
            <img src="/static/houtai/images/logo.png" alt="" />
          </small>
        </a>
      </div>
      <!-- /Navbar Barnd -->
      <!-- Sidebar Collapse -->
      <div class="sidebar-collapse" id="sidebar-collapse">
        <i class="collapse-icon fa fa-bars"></i>
      </div>
      <!-- /Sidebar Collapse -->
      <!-- Account Area and Settings -->
      <div class="navbar-header pull-right">
        <div class="navbar-account">
          <ul class="account-area">
            <li>
              <a class="login-area dropdown-toggle" data-toggle="dropdown">
                <div class="avatar" title="View your public profile">
                  <img src="/static/houtai/images/adam-jansen.jpg" />
                </div>
                <section>
                  <h2>
                    <span class="profile"><span><?php echo htmlentities($username); ?></span></span>
                  </h2>
                </section>
              </a>
              <!--Login Area Dropdown-->
              <ul
                class="pull-right dropdown-menu dropdown-arrow dropdown-login-area"
              >
                <li class="username"><a>David Stevenson</a></li>
                <li class="dropdown-footer">
                  <a href="/admin/user/logout.html"> 退出登录 </a>
                </li>
                <li class="dropdown-footer">
                  <a href="/admin/user/changePwd.html"> 修改密码 </a>
                </li>
              </ul>
              <!--/Login Area Dropdown-->
            </li>
            <!-- /Account Area -->
            <!--Note: notice that setting div must start right after account area list.
                            no space must be between these elements-->
            <!-- Settings -->
          </ul>
        </div>
      </div>
      <!-- /Account Area and Settings -->
    </div>
  </div>
</div>

<!-- /头部 -->

	
	
	<div class="main-container container-fluid">
		<div class="page-container">
            <!-- Page Sidebar -->
<div class="page-sidebar" id="sidebar">
  <!-- Page Sidebar Header-->
  <div class="sidebar-header-wrapper">
    <input class="searchinput" type="text" />
    <i class="searchicon fa fa-search"></i>
    <div class="searchhelper">
      Search Reports, Charts, Emails or Notifications
    </div>
  </div>
  <!-- /Page Sidebar Header -->
  <!-- Sidebar Menu -->
  <ul class="nav sidebar-menu">
    <!--Dashboard-->
    <li>
      <a
        href="http://www.note.com/index.php/qiantai/index/index"
        target="_blank"
        class="menu-dropdown"
      >
        <i class="menu-icon fa fa-user"></i>
        <span class="menu-text"><?php if($tittle): ?><?php echo htmlentities($tittle); ?><?php endif; ?></span>
        <i class="menu-expand"></i>
      </a>
    </li>
    <!-- 此处用循环挺好，但是我懒得再在数据库里加链接了，就这样吧 -->
    <!-- <?php foreach($left as $v): ?>
    <li>
      <a
        href="http://www.note.com/index.php/houtai/article/index/article.html"
        class="menu-dropdown"
      >
        <i class="menu-icon fa fa-user"></i>
        <span class="menu-text"><?php echo htmlentities($v['tittle']); ?></span>
        <i class="menu-expand"></i>
      </a>
      <?php foreach($v['lists'] as $vv): ?>
      <ul class="submenu">
        <li>
          <a href="index/article.html">
            <span class="menu-text"> <?php echo htmlentities($vv['tittle']); ?> </span>

            <i class="menu-expand"></i>
          </a>
        </li>
      </ul>
      <?php endforeach; ?>
    </li>
    <?php endforeach; ?> -->
    <li>
      <a
        href="http://www.note.com/index.php/houtai/article/index"
        class="menu-dropdown"
      >
        <i class="menu-icon fa fa-user"></i>
        <span class="menu-text">文档管理</span>
        <i class="menu-expand"></i>
      </a>
     
      <ul class="submenu">
        <li>
          <a href="http://www.note.com/index.php/houtai/article/index">
            <span class="menu-text"> 文档列表</span>

            <i class="menu-expand"></i>
          </a>
        </li>
      </ul>
    </li>
    
    <li>
      <a
        href="http://www.note.com/index.php/houtai/user/index"
        class="menu-dropdown"
      >
        <i class="menu-icon fa fa-user"></i>
        <span class="menu-text">用户管理</span>
        <i class="menu-expand"></i>
      </a>
     
      <ul class="submenu">
        <li>
          <a href="http://www.note.com/index.php/houtai/user/index">
            <span class="menu-text"> 用户列表</span>

            <i class="menu-expand"></i>
          </a>
        </li>
      </ul>
    </li>
  <!-- /Sidebar Menu -->
</div>
<!-- /Page Sidebar -->

            <!-- Page Content -->
            <div class="page-content">
                <!-- Page Breadcrumb -->
                <div class="page-breadcrumbs">
                    <ul class="breadcrumb">
                                        <li class="active">控制面板</li>
                                        </ul>
                </div>
                <!-- /Page Breadcrumb -->

                <!-- Page Body -->
                <div class="page-body">
                    
				<div style="text-align:left; line-height:1000%; font-size:24px;">
               
                <p style="color:rgb(20, 163, 220);">
                    <?php echo htmlentities($username); ?>宝贝，欢迎回来，今天有什么想说的吗
                    前言：<br><br>
                    作为人生中搭建的第一个网站<br>
                    虽然有很多不足，但是能做出来已经很开心了<br>
                    学艺不精，只能做成如此模样了<br><br>
                    这个小系统可以满足日常笔记记录的需求<br>
                    也可以作为自己日常吐槽的小平台<br>
                    并且不用担心自己的小心思被发现，还是很有意思的<br>
                    也许后续会继续对这个小平台进行修改完善，目前就暂且这样吧<br><br>
                ps这个寒假过得很充实，且通过此次实战对web有了更加深刻的认识<br><br>
                --2023.01.30
            </p></div>
                </div>
                

                </div>
                <!-- /Page Body -->
            </div>
            <!-- /Page Content -->
		</div>	
	</div>

    <!--Basic Scripts-->
<script src="/static/houtai/style/jquery_002.js"></script>
<script src="/static/houtai/style/bootstrap.js"></script>
<script src="/static/houtai/style/jquery.js"></script>
<!--Beyond Scripts-->
<script src="/static/houtai/style/beyond.js"></script>



</body></html>